package com.android.tdsoft.assignment.base;

/**
 * Created by Admin on 4/29/2016.
 */
public interface BasePresenter {
    void start();
}
