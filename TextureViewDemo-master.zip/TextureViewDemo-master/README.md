TextureViewDemo
===============
Branch Master: [![Build Status](https://travis-ci.org/dalinaum/TextureViewDemo.png?branch=master)](https://travis-ci.org/dalinaum/TextureViewDemo)

It includes very simple `TextureView` demos. 

You can download this app from the link below.

[![Download](http://developer.android.com/images/brand/en_generic_rgb_wo_60.png)](https://play.google.com/store/apps/details?id=kr.gdg.android.textureview)

License
-------
It is absolutely free. That's all.
